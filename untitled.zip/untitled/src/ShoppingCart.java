import java.lang.reflect.Array;
import java.util.*;


/**
 * This is the current implementation of ShoppingCart.
 * Please write a replacement
 */
public class ShoppingCart implements IShoppingCart {
    HashMap<String, Integer> contents = new LinkedHashMap<>();
    Pricer pricer;
    String recType;
    public ShoppingCart(Pricer pricer) {
        this.pricer = pricer;
        recType = "Basic";
    }
    public ShoppingCart(Pricer pricer, String recType) {
        this.pricer = pricer;
        this.recType = recType;
    }
    public void addItem(String itemType, int number) {
        if (!contents.containsKey(itemType)) {
            contents.put(itemType, number);
        } else {
            int existing = contents.get(itemType);
            contents.put(itemType, existing + number);
        }
    }

    public void printReceipt() {
        Object[] keys = contents.keySet().toArray();
        Float priceFloatTotal =0.0f;
        for (int i = 0; i < Array.getLength(keys) ; i++) {
            Integer price = pricer.getPrice((String)keys[i]) * contents.get(keys[i]);

            //Line 37 - Had to be fixed and changed using valueOf. The previous version was older and not compatible.
            Float priceFloat = Float.valueOf(price / 100);
            String priceString = String.format("€%.2f", priceFloat);
            priceFloatTotal+=priceFloat;

            if(recType.equals("Basic"))
                System.out.println(keys[i] + " - " + contents.get(keys[i]) + " - " + priceString);
            else
                System.out.println(priceString + " - " + keys[i] + " - " + contents.get(keys[i]));
        }
        //format as string
        //print
        String total = String.format("€%.2f", priceFloatTotal);
        System.out.println("Total: " + total);
    }
}
